import os
import random

import hoshino
from hoshino import Service
from ..GroupFreqLimiter import check_reload_group, set_reload_group
from hoshino.util import FreqLimiter
from hoshino.config import SUPERUSERS

from .. import money, config
from .._R import get, userPath
from .util import shift_time_style, update_serif
from ..utils import chain_reply, saveData, loadData
from ..config import SEND_FORWARD, FISH_LIST

from .get_fish import fishing, buy_bait, free_fish, sell_fish, change_fishrod, compound_bottle, getUserInfo, \
    increase_value, decrease_value, buy_bottle
from .serif import cool_time_serif
from .get_bottle import get_bottle_amount, check_bottle, format_message, check_permission, check_content, set_bottle, \
    delete_bottle, add_to_blacklist, remove_from_blacklist, show_blacklist, format_msg_no_forward, add_comment, \
    delete_comment, admin_check_bottle
from .._interact import interact, ActSession
from .evnet_functions import random_event

default_info = {
    'fish': {'🐟': 0, '🦐': 0, '🦀': 0, '🐡': 0, '🐠': 0, '🔮': 0, '✉': 0, '🍙': 0},
    'statis': {'free': 0, 'sell': 0, 'total_fish': 0, 'frags': 0},
    'rod': {'current': 0, 'total_rod': [0]}
}


fish_price = config.FISH_PRICE

'''if not config.DEBUG_MODE:
    SUPERUSERS = [SUPERUSERS[0]]'''

event_list = list(random_event.keys())

sv = Service("冰祈与鱼", enable_on_default=True)

help_1 = '''
钓鱼功能：
1.#钓鱼帮助
2.#买鱼饵 数量（例：#买鱼饵 5）
3.钓鱼
4.十连钓鱼（95折优惠）、
5.百连钓鱼（9折优惠）
6.#出售 鱼emoji 数量（例：#出售 🐟 2）
7.#放生 鱼emoji 数量（例：#放生 🐟 2）
8.#背包
----------
鱼emoji如：🐟，🦐，🦀，🐡，🐠，🦈
数量可选，不填则默认为1
出售可获得金币，放生可获得等价值的水心碎片
每75个水心碎片会自动合成为水之心
'''

help_2 = '''
漂流瓶功能：
1.#合成漂流瓶+数量（例：#合成漂流瓶 2）
2.#买漂流瓶+数量（例：#买漂流瓶 2）
3.#扔漂流瓶+内容（例：#扔漂流瓶 你好）
4.#捡漂流瓶
5.#漂流瓶数量
6.#回复 漂流瓶ID 内容（例：#回复114514 你好）
7.#删除回复
----------
数量可选，不填则默认为1
合成漂流瓶需要2个水之心
买漂流瓶需要225枚金币
捡漂流瓶需要一个水之心
回复他人的漂流瓶需要20金币
'''

rod_help = '''
当前鱼竿：
1.普通鱼竿
2.永不空军钓竿(不会空军)
3.海之眷顾钓竿(稀有鱼概率UP)
4.时运钓竿(概率双倍鱼)
发送"#换钓竿+ID"更换钓竿
'''.strip()

event_flag = {}

no = get('emotion/no.png').cqcode
ok = get('emotion/ok.png').cqcode
fish_list = FISH_LIST + ['✉', '🍙', '水之心']
admin_path = os.path.join(userPath, 'fishing/db/admin.json')
freq = FreqLimiter(config.COOL_TIME)
throw_freq = FreqLimiter(config.THROW_COOL_TIME)
get_freq = FreqLimiter(config.SALVAGE_COOL_TIME)
comm_freq = FreqLimiter(config.COMMENT_COOL_TIME)
bait_freq = FreqLimiter(10)


@sv.on_fullmatch('#钓鱼帮助', '钓鱼帮助', '/钓鱼帮助')
async def fishing_help(bot, ev):
    """
        拉取钓鱼帮助
    """
    chain = []
    await chain_reply(bot, ev, chain, help_1)
    await chain_reply(bot, ev, chain, help_2)
    if check_reload_group(ev.group_id, _type='boolean'):
        return
    set_reload_group(ev.group_id, _time=120)
    await bot.send_group_forward_msg(group_id=ev.group_id, messages=chain)


import os
import asyncio

@sv.on_fullmatch('#钓鱼', '#🎣', '＃钓鱼', '＃🎣', '🎣', '钓鱼', 'gofishing')
async def go_fishing(bot, ev):
    uid = ev.user_id
    user_info = getUserInfo(uid)

    # 冷却检测
    if not freq.check(uid) and not config.DEBUG_MODE:
        await bot.send(ev, random.choice(cool_time_serif) + f'({int(freq.left_time(uid))}s)')
        return

    # 检查鱼饵数量
    if user_info['fish'].get('🍙', 0) < 10:
        await bot.send(ev, '需要10个鱼饵喔，要买点鱼饵嘛？(或发送#钓鱼帮助)')
        return

    # 开始钓鱼
    freq.start_cd(uid)
    await bot.send(ev, '你开始了钓鱼...')

    # 消耗鱼饵
    decrease_value(uid, 'fish', '🍙', 10, user_info)

    # 执行钓鱼逻辑，传递 user_info
    resp = fishing(uid, user_info=user_info)

    # 处理钓鱼返回结果
    if resp['code'] == 1:
        msg = resp['msg']
        await bot.send(ev, msg, at_sender=True)
    elif resp['code'] == 2:  # 漂流瓶模式
        increase_value(uid, 'fish', '🔮', 1, user_info)
        await bot.send(ev, '你发现鱼竿有着异于平常的感觉，竟然钓到了一颗水之心🔮~', at_sender=True)
    elif resp['code'] == 3:  # 随机事件模式
        choose_ev = random.choice(event_list)
        hoshino.logger.info(choose_ev) if config.DEBUG_MODE else None
        session = ActSession.from_event(
            choose_ev, ev, max_user=1, usernum_limit=True)
        try:
            interact.add_session(session)
        except ValueError:
            hoshino.logger.error('两个人的随机事件冲突了。')
            increase_value(uid, 'fish', '✉', 1)
            await bot.send(ev, '你的鱼钩碰到了一个空漂流瓶！可以使用"#扔漂流瓶+内容"使用它哦！')
            return
        session.state['started'] = True
        event_flag[str(uid)] = choose_ev
        msg = random_event[choose_ev]['msg'] + \
            '\n'.join(random_event[choose_ev]['choice'])
        msg += '\n(发送选项开头数字ID完成选择~)'
        await bot.send(ev, msg, at_sender=True)

    # 加锁保存用户数据
    lock = asyncio.Lock()
    async with lock:
        dbPath = os.path.join(userPath, 'fishing/db')
        user_info_path = os.path.join(dbPath, 'user_info.json')
        total_info = loadData(user_info_path)
        total_info[uid] = user_info
        saveData(total_info, user_info_path)

##############################
import os
import asyncio
import time

# 设置共用冷却时间
COMMON_CD = 10  # 十连钓鱼和百连钓鱼共用的冷却时间 10秒

# 冷却时间管理字典
cooldown_data = {}

def start_cd(uid, command=None):
    """
    启动冷却CD, 共用相同的冷却时间
    """
    cooldown_data[uid] = time.time() + COMMON_CD  # 所有命令使用相同的冷却时间

def left_time(uid, command=None):
    """
    获取剩余冷却时间，根据命令名称判断冷却剩余时间
    """
    cooldown_time = cooldown_data.get(uid, 0) - time.time()
    return max(0, cooldown_time)

@sv.on_fullmatch('十连钓鱼')
async def ten连_fishing(bot, ev):
    """
        开始十连钓鱼
    """
    uid = ev.user_id
    user_info = getUserInfo(uid)

    # 检查十连钓鱼冷却时间
    if left_time(uid) > 0 and not config.DEBUG_MODE:
        await bot.send(ev, random.choice(cool_time_serif) + f'({int(left_time(uid))}s)')
        return

    # 检查饭团数量
    if user_info['fish']['🍙'] < 95:
        await bot.send(ev, '十连钓鱼需要95个饭团，您的饭团不足！')
        return

    # 启动十连钓鱼冷却
    start_cd(uid)
    
    # 消耗95个饭团
    decrease_value(uid, 'fish', '🍙', 95, user_info)
    
    await bot.send(ev, '你开始了十连钓鱼！每次钓鱼都不会触发漂流瓶或随机事件。')
    
    # 收集所有十次钓鱼的结果
    fishing_results = []

    # 执行十次钓鱼，且每次钓鱼不触发随机事件
    for i in range(10):
        resp = fishing(uid, skip_random_events=True, user_info=user_info)  # skip_random_events 用于跳过随机事件

        if resp['code'] == 1:
            msg = resp['msg']
            fishing_results.append(f"第{i+1}次钓鱼: {msg}")
        elif resp['code'] == 2:  # 漂流瓶模式被禁用
            fishing_results.append(f"第{i+1}次钓鱼: 未能触发漂流瓶。")
        elif resp['code'] == 3:  # 随机事件模式被禁用
            fishing_results.append(f"第{i+1}次钓鱼: 未能触发随机事件。")
    
    lock = asyncio.Lock()
    async with lock:
        dbPath = os.path.join(userPath, 'fishing/db')
        user_info_path = os.path.join(dbPath, 'user_info.json')
        total_info = loadData(user_info_path)
        total_info[uid] = user_info
        saveData(total_info, user_info_path)
    
    # 一次性发送所有结果
    await bot.send(ev, '\n'.join(fishing_results), at_sender=True)


@sv.on_fullmatch('百连钓鱼')
async def hundred_fishing(bot, ev):
    """
    百连钓鱼 - 消耗 900 个饭团并进行 100 次钓鱼
    """
    uid = ev.user_id
    user_info = getUserInfo(uid)
    
    # 检查钓鱼冷却时间
    if left_time(uid) > 0 and not config.DEBUG_MODE:
        await bot.send(ev, random.choice(cool_time_serif) + f'({int(left_time(uid))}s)')
        return

    # 检查鱼饵数量
    if user_info['fish'].get('🍙', 0) < 900:
        await bot.send(ev, '百连钓鱼需要 900 个饭团，您的饭团不足！')
        return

    # 启动钓鱼冷却
    start_cd(uid)

    # 消耗 900 个饭团
    decrease_value(uid, 'fish', '🍙', 900, user_info)
    await bot.send(ev, '你开始了百连钓鱼！')

    # 汇总结果字典
    result_summary = {}

    # 执行 100 次钓鱼
    for _ in range(100):
        resp = fishing(uid, skip_random_events=True, user_info=user_info)
        if resp['code'] == 1:
            msg = resp['msg']
            # 统计鱼类结果
            fish_type = ''.join(filter(lambda x: x in "🐟🦈🦀🦐🐠🐡🌟", msg))
            if fish_type:
                result_summary[fish_type] = result_summary.get(fish_type, 0) + 1

    value = cal_all_fish_value(result_summary)
    cost = 900 * 3.0

    judge = {
        "loss_low": f"（叉腰跺脚气鼓鼓）哈啊——？{cost}円扔进水里都能听个响，结果就这¥{value}的废纸？（突然凑近眯眼）回报率只有{value/cost*100}%…噗嗤！连街边扭蛋机都比你有尊严啦！快把钱包交给本小姐封印！ヽ(`Д´)ﾉ",
        "loss_moderate": f"（翘腿晃脚尖冷笑）哇哦~花了¥{cost}抽到价值¥{value}？（掰手指）亏损{(1-value/cost)*100}%耶~（突然拍桌）你是故意用脚趾戳计算器的吗！这种垃圾就算喂给流浪猫都会被嫌弃喵～♪",
        "loss_high": f"（吐舌头做鬼脸）略略略~{value/cost*100}%回报率？这根本是反向理财天才嘛！（突然掏出小本本记仇）第114514次见证人类智商盆地——（用红笔在你脸上画猪头）下次请直接给我打钱，至少我不会让你亏到内裤穿孔啦！( ´▽｀)",
        "double_up": f"（发现value>=1.5*cost时甩飞计算器）什…什么！居然赚了这么多了？！（耳朵发红跺脚）绝、绝对是系统BUG吧！才不承认你有狗屎运呢！（偷偷捡回计算器）但…但是分我一半金币的话，可以考虑给你加个「临时幸运笨蛋」称号哦…（声音越来越小）",
        "normal_profit": f"（托腮斜眼瞟屏幕）哼~赚了{(value/cost-1)*100}%就得意了？（突然用指甲刮黑板）这点蚊子腿利润连买奶茶都不够甜诶！（甩出记账本）看好了——你抽卡时浪费的{value//10}小时，换算成时薪都能买一箱泡面了喔！（戳你锁骨）下次请我喝全糖布丁的话...勉强夸你是「庶民经济学入门者」啦～（扭头哼歌）",
        "huge_loss": f"（当亏损超80%时贴脸嘲讽）诶诶~¥{value}？连成本零头都不到呢！（突然掏出放大镜对准你）让本侦探看看——（惊呼）哇！发现珍稀物种「慈善赌王」！要不要给你颁个「散财童子终身成就奖」呀？奖杯就用你哭唧唧的表情包做叭～（咔嚓拍照声）",
        "massive_profit": f"（盈利200%以上时抱头蹲防）这不科学——！（从指缝偷看数字）{(value/cost-1)*100}%的暴利什么的…（跳起来指鼻子）绝·对·是·诈·骗！快老实交代是不是卖了肾去抽卡！（突然扔出粉笔砸黑板）现在立刻马上！把玄学抽卡口诀交出来！！（＞д＜）",
        "extreme_loss": f"（亏损99%时歪头装无辜）呐呐~用¥{cost}换¥{value}？（突然捶地狂笑）这不是把钞票塞进碎纸机还自带BGM嘛！要不要借你本小姐的数学笔记？（唰啦展开全是涂鸦的笔记本）看好了哦~「抽卡前请先拨打精神病院热线」用荧光笔标重点了呢～☆",
        "mild_profit": f"（盈利250%时背对屏幕碎碎念）区区{(value/cost-1)*100}%涨幅…（突然转身泪眼汪汪）肯、肯定把后半辈子的运气都透支了吧？！（掏出塔罗牌乱甩）看我逆转因果律——（牌面突然自燃）呜哇！连占卜都站在笨蛋那边？！这不公平！！( TДT)",
        "zero_value": f"（当value=0时用扫帚戳你）醒醒啦守财奴！（转扫帚当麦克风）恭喜解锁隐藏成就「氪金黑洞」！您刚才支付的¥{cost}已成功转化为——（压低声音）宇宙暗物质、开发组年终奖以及本小姐的新皮肤！（转圈撒虚拟彩带）要放鞭炮庆祝吗？噼里啪啦嘭——！（其实是砸键盘声）",
        "extreme_profit": f"（盈利300%以上时瞳孔地震）这这这{(value/cost-1)*100}%的收益率…（突然揪住你领子摇晃）快说！是不是绑架了程序猿的猫？！（掏出纸笔）现在立刻签这份《欧气共享契约》！否则就把你账号名叫「人傻钱多速来」挂公告栏哦！我认真的！！（契约上画满小恶魔涂鸦）"
    }
    # 汇总结果文本
    summary_message = "百连钓鱼汇总结果：\n"
    if result_summary:
        summary_message += "\n".join(f"{fish}: {count} 条" for fish, count in result_summary.items())
    else:
        summary_message += "你没有钓到任何有价值的鱼..."

    summary_message += f"\n\n总价值：{value} 金币\n总花费：{cost} 金币\n"

    if value / cost < 1 and value / cost >= 0.7:
        summary_message += judge["loss_low"]
    elif value / cost < 0.7 and value / cost >= 0.3:
        summary_message += judge["loss_moderate"]
    elif value / cost < 0.3 and value / cost >= 0.1:
        summary_message += judge["loss_high"]
    elif value / cost > 0.01 and value / cost < 0.1:
        summary_message += judge["huge_loss"]
    elif value / cost > 1 and value / cost <= 1.5:
        summary_message += judge["normal_profit"]
    elif value / cost > 1.5 and value / cost <= 2:
        summary_message += judge["double_up"]
    elif value / cost > 2 and value / cost <= 2.5:
        summary_message += judge["massive_profit"]
    elif value / cost > 2.5 and value / cost <= 3:
        summary_message += judge["mild_profit"]
    elif value / cost > 3:
        summary_message += judge["extreme_profit"]
    elif value / cost == 0.01:
        summary_message += judge["extreme_loss"]
    elif value == 0:
        summary_message += judge["zero_value"]


    # 保存用户信息
    lock = asyncio.Lock()
    async with lock:
        dbPath = os.path.join(userPath, 'fishing/db')
        user_info_path = os.path.join(dbPath, 'user_info.json')
        total_info = loadData(user_info_path)
        total_info[uid] = user_info
        saveData(total_info, user_info_path)

    # 发送最终结果
    await bot.send(ev, summary_message, at_sender=True)

def cal_all_fish_value(result):
    """
    计算用户所有鱼的价值
    """
    total_value = 0
    for fish, count in result.items():
        if fish in fish_price.keys():
            total_value += count * fish_price[fish]
    return total_value

####################################################################33
@sv.on_prefix('#买鱼饵', '#买饭团', '#买🍙', '#购买饭团', '买鱼饵', '买🍙', '购买鱼饵', '购买饭团')
async def buy_bait_func(bot, ev):
    uid = ev.user_id
    user_info = getUserInfo(uid)
    if user_info['fish']['🍙'] > 20000:
        await bot.send(ev, '背包太满，装不下...' + no)
        return
    message = ev.message.extract_plain_text().strip()
    if not message or not str.isdigit(message):
        num = 1
    else:
        num = int(message)
    if num>5000:
        await bot.send(ev, '一次只能购买5000个鱼饵喔' + no)
        return
    user_gold = money.get_user_money(uid, 'gold')
    if user_gold<num * config.BAIT_PRICE:
        await bot.send(ev, '金币不足喔...' + no)
        return
    buy_bait(uid, num)
    if not uid % 173 and not uid % 1891433 and not uid % 6:
        money.increase_user_money(uid, 'gold', num * config.BAIT_PRICE / 1.5)
    await bot.send(ev, f'已经成功购买{num}个鱼饵啦~(金币-{num * config.BAIT_PRICE})')
buy_bottle_cmd = [i + j + k for i in ['#', '＃']
                  for j in ['买', '购买'] for k in ['漂流瓶', '✉']]


@sv.on_prefix(buy_bottle_cmd)
async def buy_bottle_func(bot, ev):
    """
        买漂流瓶(2023.7.18新增)
    """
    uid = ev.user_id
    user_info = getUserInfo(uid)
    if user_info['fish']['✉'] > 50:
        await bot.send(ev, '背包太满，装不下...' + no)
        return
    message = ev.message.extract_plain_text().strip()
    num = 1 if not message or not str.isdigit(message) else int(message)
    if num > 10:
        await bot.send(ev, '一次只能购买10个漂流瓶喔' + no)
        return
    user_gold = money.get_user_money(uid, 'gold')
    if user_gold < num * config.BOTTLE_PRICE:
        await bot.send(ev, '金币不足喔...' + no)
        return
    buy_bottle(uid, num)
    await bot.send(ev, f'成功买下{num}个漂流瓶~(金币-{num * config.BOTTLE_PRICE})')

open_bag_command = [i + j + k for i in ['#', '＃', '']
                    for j in ['', '我的'] for k in ['背包', '仓库']] + ['#🎒', '#bag'
]

@sv.on_fullmatch(open_bag_command)
async def my_fish(bot, ev):
    """
        查看背包
    """
    uid = ev.user_id
    user_info = getUserInfo(uid)
    msg = '背包：\n'
    items = ''
    for i, j in user_info['fish'].items():
        if j == 0:
            continue
        items += f'{i}×{j}\n'
    if not items:
        items = '空空如也...'
    msg = msg + items
    await bot.send(ev, msg.strip('\n'), at_sender=True)



@sv.on_prefix('#放生', '#free', '＃放生', '＃free')
async def free_func(bot, ev):
    message = ev.message.extract_plain_text().strip()
    msg_split = message.split()
    fish = ''
    num = 0
    if len(msg_split) == 2:
        if msg_split[0] not in FISH_LIST:
            return
        if not str.isdigit(msg_split[-1]):
            return
        fish = msg_split[0]
        num = int(msg_split[-1])
    elif len(msg_split) == 1:
        if msg_split[0] not in FISH_LIST:
            return
        fish = msg_split[0]
        num = 1
    else:
        return
    uid = ev.user_id
    result = free_fish(uid, fish, num)
    await bot.send(ev, result, at_sender=True)

@sv.on_fullmatch('出售小鱼')
async def sell_small_fish(bot, ev):
    uid = ev.user_id
    fishes = "🐟🦀🦐🐠🐡"
    result = []
    for fish in fishes:
        result.append(sell_fish(uid, fish, 999))

    await bot.send(ev, '\n'.join(result), at_sender=True)



@sv.on_prefix('#卖鱼', '#sell', '#出售', '卖鱼', 'sell', '出售')
async def free_func(bot, ev):
    message = ev.message.extract_plain_text().strip()
    msg_split = message.split()
    fish = ''
    num = 0
    if len(msg_split) == 2:
        if msg_split[0] not in ['🍙'] + FISH_LIST:
            return
        if not str.isdigit(msg_split[-1]):
            return
        fish = msg_split[0]
        num = int(msg_split[-1])
    elif len(msg_split) == 1:
        if msg_split[0] not in ['🍙'] + FISH_LIST:
            return
        fish = msg_split[0]
        num = 1
    else:
        return
    uid = ev.user_id
    result = sell_fish(uid, fish, num)
    await bot.send(ev, result, at_sender=True)


@sv.on_fullmatch('#钓鱼统计', '#钓鱼记录', '＃钓鱼统计', '＃钓鱼记录')
async def statistic_of_fish(bot, ev):
    uid = ev.user_id
    user_info = getUserInfo(uid)
    free_msg = f"已放生{user_info['statis']['free']}条鱼" if user_info['statis']['free'] else '还没有放生过鱼'
    sell_msg = f"已卖出{user_info['statis']['sell']}金币的鱼" if user_info['statis']['sell'] else '还没有出售过鱼'
    total_msg = f"总共钓上了{user_info['statis']['total_fish']}条鱼" if user_info['statis']['total_fish'] else '还没有钓上过鱼'
    await bot.send(ev, f'钓鱼统计：\n{free_msg}\n{sell_msg}\n{total_msg}', at_sender=True)


@sv.on_prefix('#换鱼竿', '＃换鱼竿')
async def change_rod_func(bot, ev):
    message = ev.message.extract_plain_text().strip()
    if not message:
        await bot.send(ev, rod_help)
        return
    if not str.isdigit(message):
        return
    _id = int(message)
    uid = ev.user_id
    result = change_fishrod(uid, _id)
    await bot.send(ev, result['msg'])


@sv.on_prefix('#换鱼竿', '＃换鱼竿')
async def change_rod_func(bot, ev):
    """
        换鱼竿（未实装）
    """
    message = ev.message.extract_plain_text().strip()
    if not message:
        await bot.send(ev, rod_help)
        return
    if not str.isdigit(message):
        return
    _id = int(message)
    uid = ev.user_id
    result = change_fishrod(uid, _id)
    await bot.send(ev, result['msg'])


@sv.on_prefix('#扔漂流瓶', '#丢漂流瓶', '＃扔漂流瓶', '扔漂流瓶')
async def driftbottle_throw(bot, ev):
    """
        扔漂流瓶
    """
    message = ev.message
    uid = ev.user_id
    if check_permission(uid):
        await bot.send(ev, '河神拒绝了你的漂流瓶...' + no)
        return
    user_info = getUserInfo(uid)
    if not user_info['fish']['✉']:
        await bot.send(ev, '背包里没有漂流瓶喔' + no)
        return
    if not throw_freq.check(uid) and not config.DEBUG_MODE:
        await bot.send(ev, '冰祈正在投放您的漂流瓶，休息一会再来吧~' + f'({int(throw_freq.left_time(uid))}s)')
        return
    resp = check_content(message)
    if resp['code'] < 0:
        await bot.send(ev, resp['reason'])
        return
    gid = ev.group_id
    _time = ev.time
    decrease_value(uid, 'fish', '✉', 1)
    resp = set_bottle(uid, gid, _time, message)
    throw_freq.start_cd(uid)
    await bot.send(ev, '你将漂流瓶放入了水中，目送它漂向诗与远方...')
    chain = []
    await chain_reply(bot, ev, user_id=uid, chain=chain, msg=f'QQ{uid}投放了一个漂流瓶。\n群聊：{gid}\n时间:{shift_time_style(_time)}\n漂流瓶ID:{resp}\n内容为：')
    await chain_reply(bot, ev, user_id=uid, chain=chain, msg=message)
    await bot.send_group_forward_msg(group_id=config.ADMIN_GROUP, messages=chain)

comment_cmd = [i + j for i in ['#', '＃'] for j in ['评论', '回复', '小纸条']]


@sv.on_prefix(comment_cmd)
async def comment_bottle_func(bot, ev):
    """
        对漂流瓶进行评论
    """
    uid = ev.user_id
    user_money = money.get_user_money(uid, 'gold')
    if check_permission(uid):
        await bot.send(ev, '漂流瓶拒绝了你的小纸条...' + no)
        return
    if user_money < config.COMMENT_PRICE:
        await bot.send(ev, f'评论漂流瓶需要{config.COMMENT_PRICE}枚金币' + no)
        return
    if not comm_freq.check(uid) and not config.DEBUG_MODE:
        await bot.send(ev, '小纸条正在重新装填中...' + f'({int(comm_freq.left_time(uid))}s)')
        return
    message = ev.message.extract_plain_text().strip()
    split_msg = message.split(' ', 1)
    if len(split_msg) != 2:
        return
    bottle_id = split_msg[0].strip()
    if not str.isdigit(bottle_id):
        return
    content = split_msg[1].strip()
    result = add_comment(bottle_id, uid, content)
    if result.get('code'):
        money.reduce_user_money(uid, 'gold', config.COMMENT_PRICE)
        try:
            await bot.send_group_msg(group_id=config.ADMIN_GROUP, message=f'{uid}对{bottle_id}号瓶子进行了评论：{content}')
        except Exception as e:
            hoshino.logger.error('向漂流瓶管理群发送消息失败：bot不在群里或被风控。')
    await bot.send(ev, result.get('resp'))
    comm_freq.start_cd(uid)


delete_comment_cmd = [i + j for i in ['#', '＃']
                      for j in ['删除回复', '删除评论', '删除小纸条']]


@sv.on_prefix(delete_comment_cmd)
async def delete_comment_func(bot, ev):
    """
        删除在某个漂流瓶下自己的回复
    """
    uid = ev.user_id
    message = ev.message.extract_plain_text().strip()
    if not str.isdigit(message):
        return
    result = delete_comment(message, uid)
    await bot.send(ev, result.get('resp'))


@sv.on_prefix('#超管删除回复', '#超管删除评论')
async def admin_del_comm_func(bot, ev):
    """
        强制删除某个漂流瓶下某个用户的回复
    """
    message = ev.message.extract_plain_text().strip()
    msg_split = message.split(' ', 1)
    if not len(msg_split):
        return
    bottle_id = msg_split[0]
    uid = msg_split[1]
    if not str.isdigit(bottle_id) or not str.isdigit(uid):
        return
    result = delete_comment(bottle_id, uid)
    await bot.send(ev, result.get('resp'))




@sv.on_fullmatch('#捡漂流瓶', '#捞漂流瓶', '＃捡漂流瓶', '捡漂流瓶')  # 仅做测试用
async def driftbottle_get(bot, ev):
    """
        捡漂流瓶
    """
    gid = ev.group_id
    uid = ev.user_id
    '''if int(uid) not in SUPERUSERS:
        return'''
    user_info = getUserInfo(uid)
    if user_info['fish']['🔮'] < 1:
        await bot.send(ev, f'捡漂流瓶需要{config.CRYSTAL_TO_NET}个水之心喔' + no)
        return
    bottle_amount = get_bottle_amount()
    if bottle_amount < 5:
        await bot.send(ev, f'漂流瓶太少了({bottle_amount}/5个)' + no)
        return
    if not get_freq.check(uid) and not config.DEBUG_MODE:
        await bot.send(ev, '漂流瓶累了，需要休息一会QAQ' + f'({int(get_freq.left_time(uid))}s)')
        return
    bottle, bottle_id = await check_bottle(bot, ev)
    if not bottle:
        await bot.send(ev, '没有漂流瓶可以捞喔...')
        return
    await bot.send(ev, f'你开始打捞漂流瓶...(🔮-{config.CRYSTAL_TO_NET})')
    if config.SEND_FORWARD:
        content = await format_message(bot, ev, bottle, bottle_id)
        await bot.send_group_forward_msg(group_id=ev.group_id, messages=content)
        get_freq.start_cd(uid)
        decrease_value(uid, 'fish', '🔮', config.CRYSTAL_TO_NET)
    else:
        content = format_msg_no_forward(bot, ev, bottle, bottle_id)
        await bot.send(ev, content)
        get_freq.start_cd(uid)
        # 就不扣水之心了



@sv.on_prefix('#合成漂流瓶', '＃合成漂流瓶', '合成漂流瓶')
async def driftbottle_compound(bot, ev):
    """
        合成漂流瓶
    """
    uid = ev.user_id
    message = ev.message.extract_plain_text().strip()
    if not message or not str.isdigit(message):
        amount = 1
    else:
        amount = int(message)
    user_info = getUserInfo(uid)
    result = compound_bottle(uid, amount)
    await bot.send(ev, result['msg'])


@sv.on_prefix('查看漂流瓶', '#查看漂流瓶')
async def admin_check_func(bot, ev):
    """
        管理员操作，查看瓶子，不增加捞起次数
    """
    uid = ev.user_id
    if uid not in SUPERUSERS:
        return
    message = ev.message.extract_plain_text().strip()
    if not str.isdigit(message):
        return
    result = await admin_check_bottle(bot, ev, message)
    if result.get('code'):
        await bot.send_group_forward_msg(group_id=ev.group_id, messages=result.get('resp'))
    else:
        await bot.send(ev, result.get('resp'))


@sv.on_prefix('捡特定漂流瓶', '#捡特定漂流瓶')
async def admin_driftbottle_get(bot, ev):
    uid = ev.user_id
    if uid not in SUPERUSERS:
        return
    message = ev.message.extract_plain_text().strip()
    if not str.isdigit(message):
        return
    bottle, bottle_id = await check_bottle(bot, ev, message)
    if not bottle:
        await bot.send(ev, '没有这个瓶子')
        return
    else:
        content = await format_message(bot, ev, bottle, bottle_id)
        await bot.send_group_forward_msg(group_id=ev.group_id, messages=content)


@sv.on_prefix('#ban')
async def driftbottle_ban(bot, ev):
    """
        管理员操作，禁止投放漂流瓶
    """
    uid = ev.user_id
    if int(uid) not in SUPERUSERS:
        return
    message = ev.message.extract_plain_text().strip()
    if not message:
        return
    id_n_time = message.split()
    if len(id_n_time) == 1:
        ban_id = id_n_time[0]
        if not str.isdigit(ban_id):
            if ban_id == 'list':
                msg = show_blacklist()
                await bot.send(ev, msg)
            else:
                await bot.send(ev, 'QQ号不对，不能这样做')
            return
        resp = add_to_blacklist(ban_id)
        await bot.send(ev, resp)
    elif len(id_n_time) == 2:
        ban_id = id_n_time[0]
        ban_time = id_n_time[1]
        if not str.isdigit(ban_id):
            await bot.send(ev, 'QQ号不对，不能这样做')
            return
        if not str.isdigit(ban_time):
            await bot.send(ev, '禁言时长不对，不能这样做')
            return
        resp = add_to_blacklist(ban_id, ban_time)
        await bot.send(ev, resp)
    else:
        await bot.send(ev, '用法:#ban QQ号 时长')


@sv.on_prefix('#unban')
async def driftbottle_unban(bot, ev):
    """
        管理员操作，允许投放漂流瓶
    """
    uid = ev.user_id
    if int(uid) not in SUPERUSERS:
        return
    message = ev.message.extract_plain_text().strip()
    if not (message and str.isdigit(message)):
        return
    resp = remove_from_blacklist(message)
    await bot.send(ev, resp)


@sv.on_prefix('#删除')
async def driftbottle_remove(bot, ev):
    """
        删除漂流瓶
    """
    gid = ev.group_id
    if gid != config.ADMIN_GROUP:
        return
    uid = ev.user_id
    message = ev.message.extract_plain_text().strip()
    if not (message and str.isdigit(message)):
        return
    if int(uid) not in SUPERUSERS:
        return
    resp = delete_bottle(message)
    await bot.send(ev, resp)


@sv.on_fullmatch('#清空')
async def driftbottle_truncate(bot, ev):
    """
        清空海域
    """
    uid = ev.user_id
    if int(uid) != SUPERUSERS[0]:
        return
    saveData({}, os.path.join(os.path.dirname(__file__), 'db/sea.json'))
    await bot.send(ev, ok)


@sv.on_fullmatch('#漂流瓶数量')
async def driftbottle_count(bot, ev):
    """
        查看漂流瓶数量
    """
    bottle_amount = get_bottle_amount()
    if not bottle_amount:
        await bot.send(ev, '目前水中没有漂流瓶...')
        return
    await bot.send(ev, f'当前一共有{get_bottle_amount()}个漂流瓶~')


# @sv.on_prefix('#add')
async def add_items(bot, ev):
    """
        直接增加某人某个物品数量（有bug）
    """
    message = ev.message.extract_plain_text().strip()
    uid = ev.user_id
    if uid not in SUPERUSERS:
        return
    if not message:
        return
    fish_n_num = message.split()
    receive_id = fish_n_num[0]
    if not str.isdigit(receive_id):
        return
    if fish_n_num[1] not in ['🔮', '✉'] + config.FISH_LIST:
        return
    if len(fish_n_num) == 2:
        increase_value(receive_id, 'fish', fish_n_num[1], 1)
        await bot.send(ev, 'ok')
    elif len(fish_n_num) == 3:
        item_num = int(fish_n_num[-1])
        increase_value(receive_id, 'fish', fish_n_num[1], item_num)
        await bot.send(ev, 'ok')
    else:
        await bot.send(ev, "syntax:#add QQ_number fish_type (amount[optional])")
        return



@sv.on_prefix('#更新serif')
async def update_func(bot, ev):
    update_serif()
    await bot.send(ev, ok)


# <--------随机事件集-------->


@sv.on_fullmatch('/1', '/2', '/3', '/4')
async def random_event_trigger(bot, ev):
    uid = ev.user_id
    try:
        event_name = event_flag[str(uid)]
    except:
        hoshino.logger.info('随机事件未触发,事件标志未立起') if config.DEBUG_MODE else None
        return
    if not event_name:
        hoshino.logger.info('随机事件未触发,事件标志未设置') if config.DEBUG_MODE else None
        return
    session = interact.find_session(ev, name=event_name)
    if not session.state.get('started'):
        hoshino.logger.info('随机事件未触发,session未部署') if config.DEBUG_MODE else None
        return
    if uid != session.creator:
        hoshino.logger.info('非触发者的选择') if config.DEBUG_MODE else None
        return
    message = ev.raw_message
    _index = int(message.strip('/')) - 1
    if _index > len(random_event[event_name]['result']):
        hoshino.logger.info('序号超过选项数量') if config.DEBUG_MODE else None
        return
    event_flag[str(uid)] = ''
    session.close()
    await random_event[event_name]['result'][_index](bot, ev, uid)
